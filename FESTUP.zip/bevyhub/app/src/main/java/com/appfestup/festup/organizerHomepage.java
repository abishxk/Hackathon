package com.appfestup.festup;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class organizerHomepage extends AppCompatActivity {

    Button organizerProfile,upcomingeve,newupload,edtcollgdet,edtupldet,orgtopar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_organizer_homepage);

        organizerProfile = findViewById(R.id.organizerProfile);
        upcomingeve=findViewById(R.id.upcomingeve);
        newupload=findViewById(R.id.newupload);
        edtcollgdet=findViewById(R.id.edtcollgdet);
        edtupldet=findViewById(R.id.edtupldet);
        orgtopar=findViewById(R.id.orgtopar);

        organizerProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(organizerHomepage.this, organizerProfile.class));
            }
        });

        upcomingeve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(organizerHomepage.this, upcomingeve.class));
            }
        });

        newupload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(organizerHomepage.this, newupload.class));
            }
        });

        edtcollgdet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(organizerHomepage.this, edtcollgdet.class));
            }
        });

        edtupldet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(organizerHomepage.this, edtupldet.class));
            }
        });

        orgtopar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(organizerHomepage.this, orgtopar.class));
            }
        });
    }

}