package com.appfestup.festup;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

public class participantHomePage extends AppCompatActivity {

    Button partProfile,partpreeve,upcomingeve,techeve,nontecheve,collegedet;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_participant_home_page);

        partProfile = findViewById(R.id.partProfile);
        partpreeve=findViewById(R.id.partpreeve);
        upcomingeve=findViewById(R.id.upcomingeve);
        techeve=findViewById(R.id.techeve);
        nontecheve=findViewById(R.id.nontecheve);
        collegedet=findViewById(R.id.collegedet);

        partProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(participantHomePage.this, partProfile.class));
            }
        });

        partpreeve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(participantHomePage.this, partpreeve.class));
            }
        });

        nontecheve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(participantHomePage.this, nontecheve.class));
            }
        });

        upcomingeve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(participantHomePage.this, upcomingeve.class));
            }
        });

        collegedet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 startActivity(new Intent(participantHomePage.this, collegedet.class));
            }
        });

        techeve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(participantHomePage.this, techeve.class));
            }
        });
        
    }
}