package com.appfestup.festup;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class edtcollgdet extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edtcollgdet);
    }
}