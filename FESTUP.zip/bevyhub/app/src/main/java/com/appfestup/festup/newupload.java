package com.appfestup.festup;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.telecom.Call;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class newupload extends AppCompatActivity {


    EditText eventdetails, reglink, coordcontactinfo, eventrelevence, medialink;
    Button upload;

    //DatabaseReference reference, reference1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_page_organizer);

        eventdetails = findViewById(R.id.eventdetails);
        reglink = findViewById(R.id.reglink);
        coordcontactinfo = findViewById(R.id.coordcontactinfo);
        eventrelevence = findViewById(R.id.eventrelevence);
        medialink = findViewById(R.id.medialink);
        upload = findViewById(R.id.register);

        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
/*
                EditText eventdetails, reglink, coordcontactinfo, eventrelevence, medialink;

                ProgressDialog pd = new ProgressDialog(newupload.this);
                pd.show();
                pd.setContentView(R.layout.progress_dialog);
                pd.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

                reference = FirebaseDatabase.getInstance().getReference().child("Profile").child(et1.getText().toString());

                newupldet.det = new newupldet(et1.getText().toString(), et2.getText().toString(), et3.getText().toString(),
                        et2.getText().toString(), et4.getText().toString(), et5.getText().toString(),"organizer");

                reference.setValue(det);

                pd.dismiss();
*/
            }
        });

    }
}