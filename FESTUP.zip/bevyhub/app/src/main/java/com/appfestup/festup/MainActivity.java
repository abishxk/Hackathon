package com.appfestup.festup;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    EditText userName, password;
    TextView signUp;
    Button login;

    // DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userName = findViewById(R.id.et1);
        password = findViewById(R.id.et2);
        signUp = findViewById(R.id.t1);
        login = findViewById(R.id.b1);


        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, signUpPage.class));
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
/*
                ProgressDialog pd = new ProgressDialog(MainActivity.this);
                pd.show();
                pd.setContentView(R.layout.progress_dialog);
                pd.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

                if (userName.getText().toString().isEmpty() || password.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Enter both User Name and Password", Toast.LENGTH_SHORT).show();
                } else {

                    reference = FirebaseDatabase.getInstance().getReference("Details");
                    reference.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {

                            for (DataSnapshot ds : snapshot.getChildren()) {

                                String regNumb = ds.child("regNo").getValue().toString();
                                String name = ds.child("name").getValue().toString();
                                String cls = ds.child("cls").getValue().toString();
                                String fName = ds.child("fName").getValue().toString();
                                String fNumb = ds.child("fNumb").getValue().toString();
                                String pswd = ds.child("password").getValue().toString();

                                if (userName.getText().toString().equals(name) && password.getText().toString().equals(pswd)) {
                                    pd.dismiss();
                                    startActivity(new Intent(MainActivity.this, homePage.class));
                                } else {
                                    pd.dismiss();
                                    Toast.makeText(MainActivity.this, "Invalid Entry", Toast.LENGTH_SHORT).show();
                                }

                            }

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });


                }
*/

                startActivity(new Intent(MainActivity.this, participantHomePage.class));

            }
        });

    }
}