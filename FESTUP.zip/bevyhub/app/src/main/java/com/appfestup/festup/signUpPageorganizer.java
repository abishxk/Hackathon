package com.appfestup.festup;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.telecom.Call;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class signUpPageorganizer extends AppCompatActivity {

    EditText et1, et2, et3, et4, et5;
    Button register;

    //DatabaseReference reference, reference1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_page_organizer);

        et1 = findViewById(R.id.et1);
        et2 = findViewById(R.id.et2);
        et3 = findViewById(R.id.et3);
        et4 = findViewById(R.id.et4);
        et5 = findViewById(R.id.et5);
        register = findViewById(R.id.register);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
/*
                EditText et1, et2, et3, et4 , et5;

                ProgressDialog pd = new ProgressDialog(signUpPageorganizer.this);
                pd.show();
                pd.setContentView(R.layout.progress_dialog);
                pd.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

                reference = FirebaseDatabase.getInstance().getReference().child("Profile").child(et1.getText().toString());

                signorgdet.det = new signorgdet(et1.getText().toString(), et2.getText().toString(), et3.getText().toString(),
                        et2.getText().toString(), et4.getText().toString(), et5.getText().toString(),"organizer");

                reference.setValue(det);

                pd.dismiss();
*/
            }
        });

    }
}